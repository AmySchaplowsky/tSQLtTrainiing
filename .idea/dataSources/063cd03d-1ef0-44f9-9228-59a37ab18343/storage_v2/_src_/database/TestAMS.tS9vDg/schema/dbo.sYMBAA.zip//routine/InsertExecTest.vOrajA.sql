
CREATE PROCEDURE dbo.InsertExecTest
AS
BEGIN
	SELECT
		1
		,2
		,3;

	SELECT
		4
		,5
		,6
		,7;
END;
go

