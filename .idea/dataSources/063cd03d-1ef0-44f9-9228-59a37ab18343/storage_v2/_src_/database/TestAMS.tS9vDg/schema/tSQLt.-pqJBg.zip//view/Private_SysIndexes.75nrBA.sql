CREATE VIEW tSQLt.Private_SysIndexes AS SELECT * FROM sys.indexes;
go

