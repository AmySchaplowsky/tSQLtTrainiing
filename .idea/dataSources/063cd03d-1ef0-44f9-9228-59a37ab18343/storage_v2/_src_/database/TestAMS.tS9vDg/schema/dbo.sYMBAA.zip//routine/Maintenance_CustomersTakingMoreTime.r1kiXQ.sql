
CREATE PROC dbo.Maintenance_CustomersTakingMoreTime
AS
BEGIN
	--Stub Proc
	WAITFOR DELAY '00:00:01';
END;
go

